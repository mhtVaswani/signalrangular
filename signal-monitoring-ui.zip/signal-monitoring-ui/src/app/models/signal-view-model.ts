export class SignalViewModel {
    Id: number;
    Name: string
}
