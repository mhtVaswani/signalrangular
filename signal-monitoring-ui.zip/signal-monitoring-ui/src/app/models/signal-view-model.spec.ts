import { SignalViewModel } from './signal-view-model';

describe('SignalViewModel', () => {
  it('should create an instance', () => {
    expect(new SignalViewModel()).toBeTruthy();
  });
});
