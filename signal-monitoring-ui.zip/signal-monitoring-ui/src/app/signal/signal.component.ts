import { Component, OnInit } from '@angular/core';
import { Injectable } from '@angular/core';
import * as signalR from "@aspnet/signalr";
import { EventEmitter } from '@angular/core';
import { SignalViewModel } from '../models/signal-view-model';

@Component({
  selector: 'app-signal',
  templateUrl: './signal.component.html',
  styleUrls: ['./signal.component.css']
})
export class SignalComponent implements OnInit {

  connectionId: number;
  private hubConnection: signalR.HubConnection;

  constructor() {
    this.buildConnection();
    this.startConnection();

    //this.
  }

  ngOnInit() {
  }

  public buildConnection = () => {
    this.hubConnection = new signalR.HubConnectionBuilder().withUrl("http://localhost:61961/demo").build();
  }

  public startConnection = () => {
    this.hubConnection.start().then(() => {

      this.hubConnection.invoke("getConnectionId").then((connectionId) => {
        console.log(connectionId, " connection Id");
        this.connectionId = connectionId;

        //this.hubConnection.invoke("GetData", this.connectionId)




      })
    }).catch(err => {
      console.log('eror while starting the connection', err);

      setTimeout(function () { this.startConnection(); }, 30000);
    });

    this.hubConnection.on("messageData", (data) =>{
      console.log(data);
    })


  }




}
