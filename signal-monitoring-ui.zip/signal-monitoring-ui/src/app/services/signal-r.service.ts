// import { Injectable } from '@angular/core';
// import * as signalR from "@aspnet/signalr";
// import { EventEmitter } from '@angular/core';
// import { SignalViewModel } from '../models/signal-view-model';
// import { connect } from 'net';

// @Injectable({
//   providedIn: 'root'
// })

// export class SignalRService {

//   private hubConnection: signalR.HubConnection;
//   signalReceived = new EventEmitter<SignalViewModel>();

//   ConnectionId = "";

//   constructor() {
//     this.buildConnection();
//     this.startConnection();
//     this.waitData();
//   }

//   public buildConnection = () => {
//     this.hubConnection = new signalR.HubConnectionBuilder().withUrl("http://localhost:61961/demo").build();
//   }

//   public startConnection = () => {
//     this.hubConnection.start().then(() => {
//       console.log('connection build');
//       //this.registerSignalEvents();

//       this.hubConnection.invoke("getConnectionId").then((connectionId) => {
//         console.log(connectionId, " connection Id");
//         //this.ConnectionId = connectionId;

//         this.hubConnection.invoke("getData", connectionId);
//         // this.hubConnection.invoke("getData", connectionId)
//         // .then(() => {
//         //   this.hubConnection.on("messageData", (data) => {
//         //     console.log(data, ' message data received');
//         //   })
//         // })

//         //y});
//       })
//     }).catch(err => {
//       console.log('eror while starting the connection', err);

//       setTimeout(function () { this.startConnection(); }, 3000);
//     });

//     // this.hubConnection.invoke("getData",this.ConnectionId).then(function (data){
//     //   console.log(data, 'data got');
//     // })
//   }

//   public waitData(){
//     this.hubConnection.on("messageData", (data) => {
//       console.log(data);
//     })
//   }

//   private registerSignalEvents() {
//     this.hubConnection.on("SignalMessageReceived", (data: SignalViewModel) => {
//       this.signalReceived.emit(data);
//     });
//   }

// }
