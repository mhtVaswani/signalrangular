import { Component, OnInit } from '@angular/core';
import { Injectable } from '@angular/core';
import * as signalR from "@aspnet/signalr";
import { EventEmitter } from '@angular/core';
import { SignalViewModel } from './models/signal-view-model';
import { SignalComponent } from './signal/signal.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'signal-monitoring-ui';

  //count = new Array(1000).fill(0).map((x, i) => i);

  count = new Array(10);

  constructor() {
    var signal= new SignalComponent();
   }



  ngOnInit() {

  }
}

